-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2020 at 10:59 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_reg`
--

CREATE TABLE `admin_reg` (
  `AD_ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email_address` varchar(50) NOT NULL,
  `Password` varchar(270) NOT NULL,
  `Number` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_reg`
--

INSERT INTO `admin_reg` (`AD_ID`, `Name`, `Email_address`, `Password`, `Number`) VALUES
(1, 'raj', 'raj@ms.com', 'pbkdf2:sha256:150000$3e8gE9Yk$f09446017dcb82ec637a9ba7c3c4eae472bf9761cc3332222a60f9d386dc6d73', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `check_in`
--

CREATE TABLE `check_in` (
  `First_Name` varchar(50) NOT NULL,
  `Second_name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Country` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  `Number` varchar(15) NOT NULL,
  `Room` int(10) NOT NULL,
  `cst_id` int(50) NOT NULL,
  `Key_num` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `Room_number` int(11) NOT NULL,
  `Type` varchar(15) NOT NULL,
  `price` varchar(10) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `checked_in_by` varchar(50) NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_key` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`Room_number`, `Type`, `price`, `Status`, `checked_in_by`, `check_in_date`, `check_out_key`) VALUES
(1, 'single bedroom', '1700', 'Available', ' ', '2020-01-02', ' '),
(2, 'single bedroom', '1700', 'Available', '', '0000-00-00', ''),
(3, 'single bedroom', '1700', 'Available', ' ', '0000-00-00', ' '),
(4, 'single bedroom', '1700', 'Available', '', '0000-00-00', ''),
(5, 'Double bedroom', '3000', 'Available', '', '0000-00-00', ''),
(6, 'Double bedroom', '3000', 'Available', '', '0000-00-00', ''),
(7, 'Double bedroom', '3000', 'Available', '', '0000-00-00', ''),
(8, 'Suit Room', '10000', 'Available', '', '0000-00-00', ''),
(9, 'Suit Room', '10000', 'Available', '', '0000-00-00', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_reg`
--
ALTER TABLE `admin_reg`
  ADD UNIQUE KEY `AD_ID` (`AD_ID`);

--
-- Indexes for table `check_in`
--
ALTER TABLE `check_in`
  ADD UNIQUE KEY `cst_id` (`cst_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD UNIQUE KEY `Room_number` (`Room_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_reg`
--
ALTER TABLE `admin_reg`
  MODIFY `AD_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `check_in`
--
ALTER TABLE `check_in`
  MODIFY `cst_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `Room_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
