from flask import flash, request, redirect, render_template, session, abort, make_response, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from hotel.app.db import mysql
from hotel.app import app
import random
from datetime import datetime
import pymysql

db_name = "hotel"
table = "check_in"
table2 = "admin_reg"

def check_bill():
    global date, price, Name, Email, Number

    room_no =room
    tax = 12.5
    Invoice_num = random.randint(000, 9999)
    conn = mysql.connect()
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM rooms  WHERE Room_number=%s', (room_no))

    row = cursor.fetchone()
    if row:
        price = row[2]
        date = str(row[5])
        Name = row[4]

    cursor.execute('SELECT * FROM check_in WHERE Room =%s', (room_no))
    row = cursor.fetchone()
    if row:
        Email = row[2]
        Number = row[7]
    cursor.close()
    conn.close()



    date_format = "%Y-%m-%d"
    today = datetime.today().strftime(date_format)  # gets Today's Date

    a = datetime.strptime(today, date_format)
    b = datetime.strptime(date, date_format)
    delta = a - b
    num_of_days = delta.days  # gives NUmber of days between two days
    Total_Price = int(price) * int(num_of_days)  # gives Total Price
    Total_Price_with_tax =int(Total_Price)+((Total_Price) *(tax/100))

    details=[Invoice_num,today,Name,Email,Number,price,num_of_days,Total_Price,tax,Total_Price_with_tax]
    return details

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/home')
def home1():
    return redirect('/')

@app.route('/admin_reg')
def admin_reg():
    return render_template('admin_reg.html')


@app.route("/admin_reg1",methods=['POST'])
def admin_reg1():

    Full_name = request.form.get("firstname")

    Email = request.form.get("email")
    Password = request.form.get("password")
    Number = request.form.get("Number")
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM ' + table2 + ' WHERE EMail_address=%s', (Email))
    row = cursor.fetchone()
    if row:
        flash('Email already Exists')
        return redirect('/admin_reg')

    else:
        New_password = generate_password_hash(password=Password)
        cursor = conn.cursor()
        cursor.execute('INSERT INTO ' + table2 + ' VALUES (%s,%s, %s, %s, %s)',
                       (" ",Full_name, Email,
                        New_password, Number))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect('/admin_login')

@app.route('/admin_login')
def admin_login():
    return render_template('adm_login.html')

@app.route('/admin_login1',methods=['POST'])
def admin_login1():
    conn = None
    cursor = None

    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    if request.method == 'POST':
        if _email and _password:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM admin_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                if check_password_hash(row[3], _password):
                    session['email'] = row[2]
                    session["name"]=str(row[1])
                    cursor.close()
                    conn.close()
                    return render_template('admin_profile.html', name=str(row[1]), email=str(_email))
                else:
                    flash('Enter valid credentials')
                    return redirect('/admin_login')
            else:
                flash('Enter valid credentials')
                return redirect('/admin_login')
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')
    elif 'email' in session:
        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM admin_reg WHERE Email_address=%s"
        _email = session['email']
        sql_where = (_email,)
        cursor.execute(sql, sql_where)
        row = cursor.fetchone()
        if row:
            if check_password_hash(row[3], _password):
                session['email'] = row[2]
                session["name"] = str(row[1])
                cursor.close()
                conn.close()
                return render_template('admin_profile.html', name=str(row[1]), email=str(_email))
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')


@app.route('/adminhome',methods=['POST',"GET"])
def adminhome():
    global  name, email_add
    if 'email' in session:
        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM admin_reg WHERE Email_address=%s"
        _email = session['email']
        sql_where = (_email,)
        cursor.execute(sql, sql_where)
        row = cursor.fetchone()
        if row:
            name = str(row[1])
            email_add = _email
            return render_template('admin_profile.html', name=name, email=str(_email))
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')
    else:
        return redirect('/home')
@app.route('/check_in')
def check_in():
    return render_template('Check_in.html')

@app.route('/check_in_complete', methods=['POST'])
def check_in_complete():
    global x
    name_n = name
    email_n = email_add
    first = request.form.get("first_name")
    second = request.form.get("last_name")
    email = request.form.get("email_address")
    city = request.form.get("city")
    country = request.form.get("country")

    Gender = request.form.get("gender") 
    if str(Gender)=="option2":
        Gen = "Female"
    else:
        Gen ="Male"
    Date  = request.form.get("date_of_reg")
    number = request.form.get("phone_number")
    room = request.form.get("room_number")
    x = random.randint(000000, 999999)


    conn =mysql.connect()
    cursor = conn.cursor()

    cursor.execute('INSERT INTO '+table+' VALUES (%s,%s, %s, %s, %s,%s, %s, %s, %s,%s,%s)',(first,second,email,Gen,city,country,Date,number,room," ",x))
    cursor.close()
    conn.commit()
    conn.close()

    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute('UPDATE rooms SET Status=%s,checked_in_by=%s,check_in_date=%s,check_out_key=%s WHERE Room_number = %s',("Not Available",first,Date,str(x),room))
    cursor.close()
    conn.commit()
    conn.close()



    flash('Welcome '+first+' you have been alloted Room No : '+str(room)+ ' and  your Check out Key is : '+str(x))
    return render_template('admin_profile.html',name=name_n, email=email_n)

@app.route('/search_key',methods=['POST'])
def search_key():
    global keys
    keys = request.form.get("search_keys")
    conn = mysql.connect()
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM rooms WHERE check_out_key=%s',(str(keys)))
    x = cursor.fetchone()
    cursor.close()
    conn.close()
    return render_template('check_out.html',room_no=x[0],type = x[1],price=x[2],Checked_In_By=x[4],Check_Out_Key=x[6])


@app.route('/room_avail')
def room_avail():
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM rooms WHERE Status="Available"')
    room = cursor.fetchall()

    return render_template('room_avail.html',rooms = room)


@app.route('/check_out_complete',methods=['POST'])
def check_out_complete():
    global room, date, price
    message = request.form.to_dict()
    for i in message:
        room =i
        print(room)

    bill = check_bill()
    conn = mysql.connect()
    cursor = conn.cursor()

    cursor.execute('DELETE FROM check_in WHERE Room=%s',(room))
    conn.commit()

    conn = mysql.connect()
    cursor = conn.cursor()

    cursor.execute('UPDATE rooms SET Status=%s,checked_in_by=%s,check_out_key=%s WHERE Room_number = %s',("Available"," "," ",room))
    conn.commit()

    cursor.close()
    conn.close()

    flash('Thank you for visiting !')
    return render_template('details.html', details = bill)


@app.route('/logout')
def logout():
    if 'email' in session:
        session.pop('email', None)
    return redirect('/')
