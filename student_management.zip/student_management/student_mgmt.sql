-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2019 at 12:21 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_mgmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_reg`
--

CREATE TABLE `admin_reg` (
  `AD_ID` int(11) NOT NULL,
  `First Name` varchar(20) NOT NULL,
  `Last Name` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_reg`
--

INSERT INTO `admin_reg` (`AD_ID`, `First Name`, `Last Name`, `Email`, `Password`) VALUES
(1, 'kishore', 'kittu', 'demo@demo.com', '1234'),
(4, 'demo1', 'demo', 'demo2@gmail.com', 'pbkdf2:sha256:150000$GAJElPnE$00a5a405d01997a786d2084d2aa74eda1e765f1a10ac73cac220f61905dade2b'),
(5, 'test', 'user', 'test@gmail.com', 'pbkdf2:sha256:150000$bTdTTA6H$c312aa3387a19d740da28a18388014865ddadb7952a03eb9a02fd318be279ab6'),
(6, 'venkat', 'Kisohre', 'library@edu.com', 'pbkdf2:sha256:150000$Kcwj3Era$fbcce18877ceeb28914a9e16394aedd5a7086d5800b421744749a2a58cadf226'),
(7, 'venkata Kishore', 'Baddukonda', 'demo@demo.com', 'pbkdf2:sha256:150000$mtyU5Uc5$74bc0000975bf023a58430968ac5cd8004257d3f5e30a6716476312450867519'),
(8, 'kittu', 'b', 'demo2@gmail.com', 'pbkdf2:sha256:150000$WraEATmu$23f2f09a19997644357d4d49619bb7bec1fb02066f6599a844d9cea49d8def95'),
(9, 'demo', 'd', 'demo2@demo.com', 'pbkdf2:sha256:150000$ZD1Bq04c$69be46a0229b15511c3161aa61c767db381b44667c47694b4e56faedfa009872');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `ASN_ID` int(11) NOT NULL,
  `id` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`ASN_ID`, `id`, `Name`, `description`) VALUES
(4, '1', '3', '5'),
(5, '2', '2', '25');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `C_ID` int(11) NOT NULL,
  `Course_ID` varchar(20) NOT NULL,
  `Course_name` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`C_ID`, `Course_ID`, `Course_name`, `Description`) VALUES
(3, 'py2', 'java', 'Programming language OOPS'),
(4, '3', '3', '3');

-- --------------------------------------------------------

--
-- Table structure for table `student_assign`
--

CREATE TABLE `student_assign` (
  `stu_assn_id` int(11) NOT NULL,
  `Form_No` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Assigmemt_Id` varchar(50) NOT NULL,
  `Assigmemt_Name` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_assign`
--

INSERT INTO `student_assign` (`stu_assn_id`, `Form_No`, `Name`, `Email`, `Assigmemt_Id`, `Assigmemt_Name`, `status`) VALUES
(1, '1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
(2, '1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
(5, '1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
(7, '1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
(10, '1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
(14, '1406', 'kishore', 'venkat.kishore610@gmail.com', '1', '3', 'completed'),
(15, '1124', 'kishore', 'kishore@gmail.com', '1', '3', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `student_complaints`
--

CREATE TABLE `student_complaints` (
  `COMP_ID` int(11) NOT NULL,
  `Email_address` varchar(50) NOT NULL,
  `text` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_complaints`
--

INSERT INTO `student_complaints` (`COMP_ID`, `Email_address`, `text`) VALUES
(1, 'venkat.kishore610@gmail.com', 'not good\r\n'),
(2, 'venkat.kishore610@gmail.com', 'demo complaint2'),
(3, 'venkat.kishore610@gmail.com', 'demo3 test'),
(4, 'venkat.kishore610@gmail.com', 'test 1'),
(5, 'venkat.kishore610@gmail.com', 'test'),
(6, 'venkat.kishore610@gmail.com', 'complaint1'),
(7, 'venkat.kishore610@gmail.com', 'raise complaint'),
(8, 'venkat.kishore610@gmail.com', 'test complaint form '),
(9, 'venkat.kishore610@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--

CREATE TABLE `student_courses` (
  `STU_COUR_ID` int(11) NOT NULL,
  `Form_No` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Course_id` varchar(50) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Email_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_courses`
--

INSERT INTO `student_courses` (`STU_COUR_ID`, `Form_No`, `Name`, `Course_id`, `course_name`, `Status`, `Email_address`) VALUES
(1, '1406', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
(9, '1406', 'kishore', 'py2', 'java', 'completed', 'venkat.kishore610@gmail.com'),
(11, '1406', 'kishore', 'py2', 'java', 'completed', 'venkat.kishore610@gmail.com'),
(12, '1406', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
(15, '1406', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
(16, '1406', 'kishore', 'py2', 'java', 'completed', 'venkat.kishore610@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `student_reg`
--

CREATE TABLE `student_reg` (
  `STD_ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `FormNo` varchar(50) NOT NULL,
  `Contact Number` varchar(15) NOT NULL,
  `Email_address` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Address` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_reg`
--

INSERT INTO `student_reg` (`STD_ID`, `Name`, `Course`, `Semester`, `FormNo`, `Contact Number`, `Email_address`, `Password`, `Address`) VALUES
(1, 'kishore', 'ece', '1', '1406', '2147483647', 'venkat.kishore610@gmail.com', 'pbkdf2:sha256:150000$k1Ud5dzh$d0347f416e89ea486b33c988c9be65730329b2dd6d712f73c9920103a006a82e', 'Pennada, agraharam.'),
(2, 'venkat', 'CSE', '2', '1611', '1223344569', 'kishorekittu401@gmail.com', 'pbkdf2:sha256:150000$BmBlBZ91$94662eca8de073ea522229ce1878ce492ee4b7cb26849224bedb8965009bd2fc', 'bhimavaram'),
(7, 'kishore', 'CSE', '2', '1124', '7382181611', 'kishore@gmail.com', 'pbkdf2:sha256:150000$sFibAO05$81310fbae3e31bad8fc266919b2a10e7c13b290d4f847e71880902be5d4c3e18', 'hyderabad'),
(8, 'veni', 'Digital Marketing', '2', '6259', '9886292659', 'nagaveniraj2@gmail.com', 'pbkdf2:sha256:150000$sEekNdoS$381a51df6a3fe2315d69ca385a5e3a0fba1f52c37ef476aed157c6760943de53', 'vizag');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_reg`
--
ALTER TABLE `admin_reg`
  ADD PRIMARY KEY (`AD_ID`);

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`ASN_ID`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`C_ID`);

--
-- Indexes for table `student_assign`
--
ALTER TABLE `student_assign`
  ADD PRIMARY KEY (`stu_assn_id`);

--
-- Indexes for table `student_complaints`
--
ALTER TABLE `student_complaints`
  ADD PRIMARY KEY (`COMP_ID`);

--
-- Indexes for table `student_courses`
--
ALTER TABLE `student_courses`
  ADD PRIMARY KEY (`STU_COUR_ID`);

--
-- Indexes for table `student_reg`
--
ALTER TABLE `student_reg`
  ADD PRIMARY KEY (`STD_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_reg`
--
ALTER TABLE `admin_reg`
  MODIFY `AD_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `ASN_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student_assign`
--
ALTER TABLE `student_assign`
  MODIFY `stu_assn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `student_complaints`
--
ALTER TABLE `student_complaints`
  MODIFY `COMP_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `student_courses`
--
ALTER TABLE `student_courses`
  MODIFY `STU_COUR_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `student_reg`
--
ALTER TABLE `student_reg`
  MODIFY `STD_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
